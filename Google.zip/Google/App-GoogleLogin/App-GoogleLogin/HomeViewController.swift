//
//  HomeViewController.swift
//  App-GoogleLogin
//
//  Created by Balasubramanian on 13/03/19.
//  Copyright © 2019 Balasubramanian. All rights reserved.
//

import UIKit
import GoogleSignIn
import AddressBook
import MediaPlayer
import AssetsLibrary
import CoreLocation
import CoreMotion

class HomeViewController: UIViewController{
    
    
    
    
    @IBOutlet var profileImgView: UIImageView!
    
    @IBOutlet var lblName: UILabel!
    
    @IBOutlet var lblEmail: UILabel!
    
   
    @IBOutlet var GoogleProfile: UITextView!
    
    @IBOutlet var emailVerified: UILabel!
    
    @IBOutlet var locale: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let logoutBarButtonItem = UIBarButtonItem(title: "Logout", style: .done, target: self, action: #selector(logoutUser))
        self.navigationItem.rightBarButtonItem  = logoutBarButtonItem
        
        self.title = "Home"
        
        
       //hide left button
        self.navigationItem.setHidesBackButton(true, animated: false)
        
        
     
        UserDefaults.standard.synchronize()
        let userData = UserDefaults.standard.value(forKey:"userData") as? [String: Any]
        print("Home userData -->\(String(describing: userData))")
        
        if let pictureUrl = userData!["picture"]{
            print("pictureUrl -->\(String(describing: pictureUrl))")
            profileImgView.downloaded(from:pictureUrl as! String)
        }
        
        //profileImgView.downloaded(from: "https://www.gstatic.com/webp/gallery3/2.png")
        
        
        if let sub = userData!["sub"]{
            print("sub -->\(String(describing: sub))")
            
        }
        
        if let name = userData!["name"]{
            print("name -->\(String(describing: name))")
            
            lblName.text! = name as! String
        }
        
        if let locale = userData!["locale"]{
            
            print("locale -->\(String(describing: locale))")
        }
        if let given_name = userData!["given_name"]{
            
            print("given_name -->\(String(describing: given_name))")
        }
        
        if let email_verified = userData!["email_verified"]{
            
            print("email_verified -->\(String(describing: email_verified))")
            
            
           
            
            let verifed  = email_verified as! Bool
            print("verifed :\(verifed)")
            
            emailVerified.text! = "\(verifed)"
            
           
        }
        
        if let email = userData!["email"]{
            
            print("email -->\(String(describing: email))")
            
            lblEmail.text! = email as! String
        }
        
       
        if let profile = userData!["profile"]{
            print("profile -->\(String(describing: profile))")
            
           GoogleProfile.text! = profile as! String
            
        }
        
        if let  family_name = userData!["family_name"]{
            print("family_name -->\(String(describing:  family_name))")
            
        }
        
        
        if let Locale = userData!["locale"]{
            
            print("locale -->\(String(describing: Locale))")
            
             locale.text! = Locale as! String
        }
        
        
        
        if let gender = userData!["gender"] {
            
            print("gender -->\(String(describing: gender))")
        }
        
    }
    
    
    @objc func logoutUser(){
        print("clicked")
        
        
        GIDSignIn.sharedInstance().signOut()
        
        
        print(GIDSignIn.sharedInstance()?.currentUser != nil) // true - signed in // false - signed out
        GIDSignIn.sharedInstance()?.disconnect()
        print(GIDSignIn.sharedInstance()?.currentUser != nil) // true - still signed in
        
        /* check for user's token */
        if GIDSignIn.sharedInstance().hasAuthInKeychain() {
            //hasAuthInKeychain() : Checks whether the user has either currently signed in or has previous authentication saved in keychain.
            //Not logged out
            //Write your code here
            
            print("Not logged out")
        } else {
            //Logged out
            print("logged out")
            
            //Write logged out code here
            //EX:
            //self.navigationController?.popToRootViewController(animated: true)
            
            DispatchQueue.main.async {
                
                UserDefaults.standard.set(false, forKey: "isUserLoggedIn")
                
                UserDefaults.standard.synchronize()
                
                self.performSegue(withIdentifier:"LoginVC", sender:self)
              
                
            }
            
        }

        
    }
    
   
    
  

   

}


extension UIImageView {
    func downloaded(from url: URL, contentMode mode: UIView.ContentMode = .scaleAspectFit) {  // for swift 4.2 syntax just use ===> mode: UIView.ContentMode
        contentMode = mode
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard
                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                let data = data, error == nil,
                let image = UIImage(data: data)
                else { return }
            DispatchQueue.main.async() {
                self.image = image
            }
            }.resume()
    }
    func downloaded(from link: String, contentMode mode: UIView.ContentMode = .scaleAspectFit) {  // for swift 4.2 syntax just use ===> mode: UIView.ContentMode
        guard let url = URL(string: link) else { return }
        downloaded(from: url, contentMode: mode)
    }
}
