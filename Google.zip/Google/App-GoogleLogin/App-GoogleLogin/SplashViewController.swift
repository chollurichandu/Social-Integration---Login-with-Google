//
//  SplashViewController.swift
//  App-GoogleLogin
//
//  Created by Balasubramanian on 13/03/19.
//  Copyright © 2019 Balasubramanian. All rights reserved.
//

import UIKit

class SplashViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        DispatchQueue.main.async {
            
            EZLoadingActivity.show("Loading...", disableUI: true)
            Timer.scheduledTimer(timeInterval:0.5, target: self, selector: #selector(self.splashTimeOut(sender:)), userInfo: nil, repeats: false)
            
        }
        
    }
    
    
    //MARK:- splashTimeOut
    
    @objc func splashTimeOut(sender : Timer){
        
        EZLoadingActivity.hide()
        
        UserDefaults.standard.synchronize()
        
        let userLoginStatus = UserDefaults.standard.bool(forKey: "isUserLoggedIn")
        
        print("\n userLoginStatus :\(userLoginStatus)")
        
        
        DispatchQueue.main.async {
        
        
        if userLoginStatus == false{
            self.performSegue(withIdentifier:"LoginVC", sender:self)
        }
        else{
            self.performSegue(withIdentifier:"HomeVC", sender:self)
        }
        
        
        }
        
        
        
        
    }


    
    /*
     //code for checking user logged in or not and re direct to concerned view controllers
     /* check for user's token */
     if GIDSignIn.sharedInstance().hasAuthInKeychain() {
     /* Code to show your view controller */
     
     
     
     print("user logged in ")
     
     
     
     } else {
     /* code to show your login VC */
     
     print("user not logged in ")
     
     }
     */
    

}
