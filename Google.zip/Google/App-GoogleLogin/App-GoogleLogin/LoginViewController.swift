//
//  ViewController.swift
//  App-GoogleLogin
//
//  Created by Balasubramanian on 13/03/19.
//  Copyright © 2019 Balasubramanian. All rights reserved.
//

import UIKit
import GoogleSignIn
import AddressBook
import MediaPlayer
import AssetsLibrary
import CoreLocation
import CoreMotion

class LoginViewController: UIViewController,GIDSignInUIDelegate,GIDSignInDelegate {
    
    
    @IBOutlet weak var signInButton: GIDSignInButton!

    @IBOutlet var GIDSignOutBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
          UserDefaults.standard.setValue(false, forKey: "_UIConstraintBasedLayoutLogUnsatisfiable")//stops printing issues related to constraints
        
        GIDSignIn.sharedInstance().uiDelegate = self
        
        // Uncomment to automatically sign in the user.
        //GIDSignIn.sharedInstance().signInSilently()
        
        // TODO(developer) Configure the sign-in button look/feel
        
        //signInButton.style = GIDSignInButtonStyle.iconOnly
        
        signInButton.colorScheme = GIDSignInButtonColorScheme.dark
        
        
        
        GIDSignIn.sharedInstance().delegate = self
        /* check for user's token */
        if GIDSignIn.sharedInstance().hasAuthInKeychain() {
            /* Code to show your view controller */
            
           
            
            print("user logged in ")
         
        } else {
            /* code to show your login VC */
            
            print("user not logged in ")
            
        }
        
    }
    
    
   

    @IBAction func GoogleLogin(_ sender: Any) {
        GIDSignIn.sharedInstance().uiDelegate=self
        GIDSignIn.sharedInstance()?.signIn()
        
      
        
    }
    
    
    //MARK:- Google Delegate
    func sign(inWillDispatch signIn: GIDSignIn!, error: Error!) {
        
        print("inWillDispatch")
    }
    
    func sign(_ signIn: GIDSignIn!,
              present viewController: UIViewController!) {
       // self.present(viewController, animated: true, completion: nil)
        
        
    }
    
    
    /*
    public func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!,
                     withError error: Error!) {
        
        print(" public func sign")
        
        
        if (error == nil) {
            // Perform any operations on signed in user here.
            let userId = user.userID                  // For client-side use only!
            let idToken = user.authentication.idToken // Safe to send to the server
            let fullName = user.profile.name
            let givenName = user.profile.givenName
            let familyName = user.profile.familyName
            let email = user.profile.email

            print("userId --> \(String(describing: userId!))")
           // print("idToken --> \(String(describing: idToken!))")
            print("fullName --> \(String(describing: fullName!))")
            print("givenName --> \(String(describing: givenName!))")
            print("familyName --> \(String(describing: familyName!))")
            print("email --> \(String(describing: email!))")


        } else {
            print("\(String(describing: error))")
        }
    }
    */
    
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!,
              withError error: Error!){
        
        
        if (error == nil) {
            
            
            DispatchQueue.main.async {
                self.moveToHomeScreen()
            }
            
            
            let gplusapi = "https://www.googleapis.com/oauth2/v3/userinfo?access_token=\(user.authentication.accessToken!)"
            let url = NSURL(string: gplusapi)!
            
            
            let request = NSMutableURLRequest(url: url as URL)
            request.httpMethod = "GET"
            request.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
            
            let session = URLSession.shared
            
            
            session.dataTask(with: request as URLRequest, completionHandler: { (data, response, error) in
                
                
                DispatchQueue.main.async {
                    UIApplication.shared.isNetworkActivityIndicatorVisible = false
                }
                
                
                
                do {
                    let userData = try JSONSerialization.jsonObject(with: data!, options:[]) as? [String:AnyObject]
                    print("userData -->\(String(describing: userData!))")
                    
                    
                    UserDefaults.standard.set(userData! as [String:Any], forKey:"userData")
                    UserDefaults.standard.synchronize()
                    
                    if let sub = userData!["sub"]{
                        print("sub -->\(String(describing: sub))")
                        
                    }
                    
                    if let name = userData!["name"]{
                        print("name -->\(String(describing: name))")
                        
                    }
                    
                    if let locale = userData!["locale"]{
                        
                        print("locale -->\(String(describing: locale))")
                    }
                    if let given_name = userData!["given_name"]{
                        
                        print("given_name -->\(String(describing: given_name))")
                    }
                    
                    
                    
                    if let email = userData!["email"]{
                        
                        print("email -->\(String(describing: email))")
                    }
                    
                    if let email_verified = userData!["email_verified"]{
                        
                        print("email_verified -->\(String(describing: email_verified))")
                    }
                    
                    if let picture = userData!["picture"]{
                        print("picture -->\(String(describing: picture))")
                        
                    }
                    if let profile = userData!["profile"]{
                        print("profile -->\(String(describing: profile))")
                        
                    }
                    
                    if let  family_name = userData!["family_name"]{
                        print("family_name -->\(String(describing:  family_name))")
                        
                    }
                    
                    
                    
                    
                    if let gender = userData!["gender"] {
                        
                        print("gender -->\(String(describing: gender))")
                    }
                    
                    
                } catch {
                    print("Account Information could not be loaded")
                }
                
            }).resume()
            
            
            
        }else{
            
            print("error --> \(String(describing: error))")
        }
        

        print("didSignInFor")

        
            
       


    }
    
    
    func moveToHomeScreen(){
        
        print("moveToHomeScreen")
        
        UserDefaults.standard.set(true, forKey: "isUserLoggedIn")
        
        UserDefaults.standard.synchronize()
        
       
        
        
        DispatchQueue.main.async {
            //self.performSegue(withIdentifier:"HomeVC", sender:self)
            
            let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "HomeViewController") as? HomeViewController
            self.navigationController?.pushViewController(vc!, animated: true)
        }
        
        
    }

    
    @IBAction func SignOut(_ sender: Any) {
        
        
        
        
        
        GIDSignIn.sharedInstance().signOut()
        
        
        print(GIDSignIn.sharedInstance()?.currentUser != nil) // true - signed in
        GIDSignIn.sharedInstance()?.disconnect()
        print(GIDSignIn.sharedInstance()?.currentUser != nil) // true - still signed in
        
        /* check for user's token */
        if GIDSignIn.sharedInstance().hasAuthInKeychain() {
            //hasAuthInKeychain() : Checks whether the user has either currently signed in or has previous authentication saved in keychain.
            //Not logged out
            //Write your code here
            
            print("Not logged out")
        } else {
            //Logged out
             print("logged out")
            
            //Write logged out code here
            //EX:
            //self.navigationController?.popToRootViewController(animated: true)
        }

    }
    
    // MARK: - GIDSignInDelegate
    func sign(_ signIn: GIDSignIn!, didDisconnectWith user: GIDGoogleUser!, withError error: Error!) {
        print(GIDSignIn.sharedInstance()?.currentUser != nil) // false - signed out
        
        // Remove any data saved to your app obtained from Google's APIs for this user.
        
        UserDefaults.standard.set(false, forKey: "isUserLoggedIn")
        
        UserDefaults.standard.synchronize()
        
    }
}

